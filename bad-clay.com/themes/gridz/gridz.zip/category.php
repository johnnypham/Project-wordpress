<?php
 /**
 * The template for displaying Category pages
 *
 * Used to display archive-type pages for posts in a category.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package gridz
 */
?>
<?php global $gridz_options; ?>
<?php get_header(); ?>
<?php if($gridz_options['sidebar_layout'] == "left"): ?>
    <?php get_sidebar(); ?>
<?php endif; ?>
<div class="wrapper">
    <h1 class=" single-title-js-1">
        <?php  $postid = get_the_ID();
           $had= get_the_category( $postid );          
          echo $had[0]->name; ?></h1>
<div id="container">
    <div id="grid-container">
  
        <?php if(have_posts()): ?>
            <?php while(have_posts()): the_post(); ?>
                <?php get_template_part('content', 'grid'); ?>
            <?php endwhile; ?>        
        <?php else : ?>
            <?php get_template_part('content', 'none'); ?>
        <?php endif; ?>
     
    </div>
       <div id="info" class="jh-none">
            <h3>BAD-CLAY STUDIO</h3>
            <p>Is a CG studio specialized in 2D/3D character concept,
            sculpting (traditional and digital), asset modeling and texturing. 
            We provide the following services for studios and production 
            companies worldwide.<p>
        </div>
    <?php gridz_pagination(); ?>
</div>
<?php if($gridz_options['sidebar_layout'] == "right"): ?>
    <?php get_sidebar(); ?>
<?php endif; ?>
<?php get_footer(); ?>