<?php
/**
 * @package gridz
 */
?>
    </div> <!-- End of content wrapper -->
</div> <!-- End of content -->
<footer id="footer">
    <div class="wrapper">
        <?php if(!is_404()) get_sidebar('footer'); ?>
        <div id="footer-credits">        	
        	
            <?php gridz_footer_credit(); ?>
       <div id="social-csjh">
	        <a href="https://www.facebook.com/pages/Bad-Clay-Studio/599409306760109?ref=ts&fref=ts"  id="social-profile-face">
	        	<span class="genericon-face"></span>
	        </a>
	        <a href="http://www.linkedin.com/company/badclay-studio?trk=top_nav_home" id="social-profile-in">
	        	<span class="genericon-in"></span>
	        </a>
	        </div>
        </div>
    </div>
</footer>
<a id="scroll-up" href="javascript:void(0)"><span class="genericon-uparrow"></span></a>
<?php wp_footer(); ?>
<script type="text/javascript">
jQuery(document).ready(function(){
	jQuery('.block-menu').find('a').each(function(){
	var el = jQuery(this),
	elText = el.text();
	el.addClass("three-d");
	el.append('<span aria-hidden="true" class="three-d-box"><span class="front">'+elText+'</span><span class="back">'+elText+'</span></span>');

	});
 jQuery(window).bind('scroll', function() {

if(jQuery('body').hasClass('home')){
   if (jQuery(window).scrollTop() > 550) {
         jQuery('#navigation').addClass('fixed');
     }
     else {
         jQuery('#navigation').removeClass('fixed');
     }

}else{
   if (jQuery(window).scrollTop() > 0) {
           jQuery('#navigation').addClass('fixed');
           jQuery('.grid-col-3 header').find('h1').addClass('fixed-1');
           jQuery('.jog').find('h1').addClass('fixed-1');
       }
   else {
       jQuery('#navigation').removeClass('fixed');
        jQuery('.grid-col-3 header').find('h1').removeClass('fixed-1');
         jQuery('.jog').find('h1').removeClass('fixed-1');
   }
}
      
  });

    var $container = jQuery(".project-container");
    $container.imagesLoaded(function() {
    $container.masonry({
    itemSelector: ".grid",
    singleMode :true,
    isAnimated: true
    });
    });

  // The slider being synced must be initialized first
  jQuery('#carousel').flexslider({
    animation: "slide",
    controlNav: false,
    animationLoop: false,
    slideshow: false,
    itemWidth: 210,
    itemMargin: 5,
    asNavFor: '#slider'
  });
   
  jQuery('#slider').flexslider({
    animation: "slide",
    controlNav: false,
    animationLoop: false,
    slideshow: false,
    sync: "#carousel"
  });

// var title=jQuery('#title-page').text()
// alert( jQuery('#title-page-js').html( title ))
//  jQuery('#title-page-js').html( title );
})


</script>
</body>
</html>